package com.java.insurance.model;

public enum Status {
	approved,processing,declined

}
